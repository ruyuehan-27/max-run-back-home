# MAX · 跑回现实

《怪奇物语》同人小游戏，帮助 Max 躲避碎石、收集音符、跑出异世界。

## 操作

- ↑ / ↓ 或 W / S：换道
- 空格：跳跃
- E：能量满后冲刺
- P / Esc：暂停或继续
- 手机可使用画面下方按钮

## 音乐现状

歌曲来源为 Kate Bush 官方 SoundCloud 播放器，歌曲为《Running Up That Hill (A Deal With God) (2018 Remaster)》。原曲音频没有打包在本仓库中。当前测试环境未能成功播放该外部音源，此问题尚未解决；播放器会显示失败提示。可选择设备上的本地音频，文件不会上传。朋友的台词是游戏提示字幕，没有模拟演员配音。

## GitHub Pages

`docs/` 已包含构建后的静态网页。在仓库 Settings → Pages 选择 Deploy from a branch，分支 `main`，目录 `/docs` 即可发布。

## 本地开发

需要 Node.js 22.13 或更高版本。

```sh
npm ci
npm run dev
npm run typecheck
npm run build
```

修改源文件后运行 `npm run build`，将源文件和 `docs/` 一起提交。

此项目为非官方同人作品；剧集、角色及歌曲属于各自权利人。
