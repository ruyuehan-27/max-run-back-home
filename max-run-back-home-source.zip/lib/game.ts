export type Mode = 'ready'|'playing'|'paused'|'won'|'lost';
export type Item = {x:number;lane:number;kind:'note'|'danger';passed:boolean};
export const lanes=[438,508,578];
export function freshGame(){return {mode:'ready' as Mode,time:0,runTime:0,distance:0,lane:1,y:508,jump:0,hp:3,energy:0,notes:0,boost:0,invincible:0,spawn:1.5,items:[] as Item[],flash:0};}
export type Game=ReturnType<typeof freshGame>;
export function action(g:Game,key:string){
 if(g.mode!=='playing')return;
 if(key==='up')g.lane=Math.max(0,g.lane-1);
 if(key==='down')g.lane=Math.min(2,g.lane+1);
 if(key==='jump'&&g.jump<=0)g.jump=.85;
 if(key==='boost'&&g.energy>=100){g.boost=3;g.energy=0;}
}
export function step(g:Game,dt:number,random:()=>number=Math.random){
 if(g.mode!=='playing')return;
 dt=Math.min(.05,Math.max(0,dt));g.time+=dt;g.runTime+=dt*(g.boost>0?1.65:1);g.distance=Math.min(1000,g.distance+dt*(g.boost>0?48:22));
 g.y+=(lanes[g.lane]-g.y)*Math.min(1,dt*16);g.jump=Math.max(0,g.jump-dt);g.boost=Math.max(0,g.boost-dt);g.invincible=Math.max(0,g.invincible-dt);g.flash=Math.max(0,g.flash-dt);
 g.spawn-=dt;
 if(g.spawn<=0&&g.distance<900){const lane=Math.floor(random()*3);g.items.push({x:1190,lane,kind:'danger',passed:false});g.items.push({x:1310,lane:(lane+1+Math.floor(random()*2))%3,kind:'note',passed:false});g.spawn=1.25+random()*.5;}
 const px=playerX(g),height=jumpHeight(g);
 for(const it of g.items){it.x-=dt*(g.boost>0?560:335);if(!it.passed&&Math.abs(it.x-px)<33&&Math.abs(g.y-lanes[it.lane])<34){
 if(it.kind==='note'){it.passed=true;g.energy=Math.min(100,g.energy+25);g.notes++;}
 else if(height<44&&g.invincible<=0&&g.boost<=0){it.passed=true;g.hp--;g.invincible=1.6;g.flash=.35;}
 }}
 g.items=g.items.filter(it=>it.x>-60&&!it.passed);
 if(g.hp<=0)g.mode='lost';else if(g.distance>=1000)g.mode='won';
}
export function playerX(g:Game){return 238+Math.max(0,(g.distance-900)/100)*775;}
export function jumpHeight(g:Game){return g.jump>0?Math.sin(g.jump/.85*Math.PI)*135:0;}
