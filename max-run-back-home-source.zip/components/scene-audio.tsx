'use client';
import {forwardRef,useEffect,useImperativeHandle,useRef,useState} from 'react';
const TRACK='https://api.soundcloud.com/tracks/600964476';
const EMBED=`https://w.soundcloud.com/player/?url=${encodeURIComponent(TRACK)}&auto_play=false&show_comments=false&show_artwork=true&color=%23ec554e`;
type Widget={bind:(event:string,callback:(data?:{currentPosition?:number})=>void)=>void;unbind:(event:string)=>void;play:()=>void;pause:()=>void;seekTo:(ms:number)=>void;setVolume:(volume:number)=>void;getDuration:(callback:(ms:number)=>void)=>void};
declare global{interface Window{SC?:{Widget:((iframe:HTMLIFrameElement)=>Widget)&{Events:Record<string,string>}}}}
export type SceneAudioControl={play:(restart?:boolean)=>void;pause:()=>void;toggle:()=>void;getStatus:()=>{source:string;ready:boolean;state:number;time:number;muted:boolean;errorCode:number|null;duration:number}};
export const SceneAudio=forwardRef<SceneAudioControl,{onPlaybackChange:(playing:boolean)=>void}>(function SceneAudio({onPlaybackChange},ref){
 const iframe=useRef<HTMLIFrameElement|null>(null),widget=useRef<Widget|null>(null),audio=useRef<HTMLAudioElement|null>(null),objectUrl=useRef('');
 const playback=useRef({ready:false,state:2,time:0,muted:false,errorCode:null as number|null,duration:0});
 const callback=useRef(onPlaybackChange);callback.current=onPlaybackChange;
 const pending=useRef(false),watchdog=useRef<ReturnType<typeof setTimeout>|null>(null);
 const [local,setLocal]=useState<{url:string;name:string}|null>(null);
 const [status,setStatus]=useState('正在连接 Kate Bush 官方原曲播放器…');
 function clearWatchdog(){if(watchdog.current)clearTimeout(watchdog.current);}
 function update(playing:boolean){playback.current.state=playing?1:2;callback.current(playing);}
 function play(restart=false){
  if(objectUrl.current){const el=audio.current;if(!el)return;if(restart)el.currentTime=0;el.muted=false;void el.play().catch(()=>setStatus('请点击音箱或本地播放器继续。'));return;}
  pending.current=true;
  if(!playback.current.ready){setStatus('官方播放器仍在加载，准备好后开始播放。');return;}
  if(restart)widget.current?.seekTo(0);
  const before=playback.current.time;playback.current.errorCode=null;widget.current?.play();setStatus('正在启动原曲…');clearWatchdog();
  watchdog.current=setTimeout(()=>{if(playback.current.time<=before){pending.current=false;playback.current.errorCode=1;widget.current?.pause();update(false);setStatus('原曲未能开始播放。当前浏览器或网络无法播放 SoundCloud 音源。');}},8000);
 }
 function pause(){pending.current=false;clearWatchdog();if(objectUrl.current)audio.current?.pause();else widget.current?.pause();}
 useImperativeHandle(ref,()=>({play,pause,toggle(){if(playback.current.state===1)pause();else play();},getStatus(){const el=audio.current;if(objectUrl.current&&el)return{source:'local',ready:el.readyState>=2,state:el.paused?2:1,time:el.currentTime,muted:el.muted,errorCode:el.error?.code??null,duration:Number.isFinite(el.duration)?el.duration:0};return{source:'soundcloud-kate-bush',...playback.current};}}));
 useEffect(()=>{
  let disposed=false;const script=document.createElement('script');script.src='https://w.soundcloud.com/player/api.js';script.async=true;
  function setup(){
   if(disposed||!iframe.current||!window.SC)return;
   const w=window.SC.Widget(iframe.current),events=window.SC.Widget.Events;widget.current=w;
   w.bind(events.READY,()=>{playback.current.ready=true;w.setVolume(65);w.getDuration(ms=>{playback.current.duration=ms/1000;});setStatus('点击右上角音箱播放 Kate Bush 原曲。');if(pending.current)play();});
   w.bind(events.PLAY,()=>{playback.current.errorCode=null;setStatus('正在缓冲原曲…');});
   w.bind(events.PLAY_PROGRESS,data=>{const position=(data?.currentPosition??0)/1000;if(position>playback.current.time){clearWatchdog();update(true);setStatus('正在播放 · Kate Bush — Running Up That Hill');}playback.current.time=position;});
   w.bind(events.PAUSE,()=>{update(false);if(playback.current.errorCode===null)setStatus('原曲已暂停，点击音箱继续。');});
   w.bind(events.FINISH,()=>{pending.current=false;if(playback.current.time<1)playback.current.errorCode=1;update(false);setStatus(playback.current.time<1?'原曲未能播放，当前音源或网络不可用。':'原曲播放结束，点击音箱重新播放。');});
   w.bind(events.ERROR,()=>{clearWatchdog();pending.current=false;playback.current.errorCode=1;update(false);setStatus('官方音源暂时不可用，请检查网络或尝试下方播放器。');});
  }
  if(window.SC)setup();else{script.onload=setup;script.onerror=()=>setStatus('无法连接 SoundCloud，请检查网络后刷新。');document.head.appendChild(script);}
  return()=>{disposed=true;pending.current=false;clearWatchdog();widget.current?.pause();if(window.SC)Object.values(window.SC.Widget.Events).forEach(event=>widget.current?.unbind(event));widget.current=null;script.remove();if(objectUrl.current)URL.revokeObjectURL(objectUrl.current);};
 },[]);
 function choose(file?:File){if(!file)return;if(!file.type.startsWith('audio/')&&!/\.(mp3|wav|m4a|ogg|aac|flac)$/i.test(file.name)){setStatus('请选择音频文件');return;}pause();update(false);if(objectUrl.current)URL.revokeObjectURL(objectUrl.current);objectUrl.current=URL.createObjectURL(file);setLocal({url:objectUrl.current,name:file.name});setStatus('本地音频已选择，仅在你的设备上播放。');}
 function restore(){pause();update(false);if(objectUrl.current)URL.revokeObjectURL(objectUrl.current);objectUrl.current='';setLocal(null);setStatus('已切换到 Kate Bush 官方原曲，点击音箱播放。');}
 return <section className="sound-deck native-sound-deck" aria-label="游戏配乐"><div className="sound-info"><p className="eyebrow">RUNNING UP THAT HILL</p><h2>{local?.name??'Running Up That Hill'}</h2><p>{local?'本地音频 · 不会上传':'Kate Bush · 2018 Remaster · 官方音源'}</p><p className="audio-status" aria-live="polite">{status}</p><p className="sound-note">音箱可播放／暂停。开始和重试从头播放，暂停游戏时音乐同步暂停。</p></div><div className="native-player"><iframe ref={iframe} title="Kate Bush 官方原曲播放器" width="100%" height="166" allow="autoplay; encrypted-media" src={EMBED} style={{border:0,borderRadius:8,display:local?'none':'block'}}/>{local&&<audio ref={audio} controls loop src={local.url} aria-label="本地音乐播放器" onPlay={()=>update(true)} onPause={()=>update(false)} onError={()=>{update(false);setStatus('本地音频无法播放。');}}/>}<details className="audio-options-details"><summary>音频选项 / 原片参考</summary><div className="audio-options"><label className="audio-file">选择本地音频<input type="file" accept="audio/*" aria-label="选择本地音频" onChange={e=>choose(e.target.files?.[0])}/></label>{local&&<button onClick={restore}>恢复官方原曲</button>}<a href="https://www.youtube.com/watch?v=bV0RAcuG2Ao" target="_blank" rel="noreferrer">Netflix 官方原片 ↗</a></div><p className="sound-note">原曲通过 SoundCloud 官方播放器在线播放，需要可访问该服务的网络。演员对白保留在 Netflix 原片中。</p></details></div></section>;
});
