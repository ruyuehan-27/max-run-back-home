'use client';

import {useEffect,useRef,useState} from 'react';
import {ArrowUp,ArrowDown,ArrowUpRight,Volume2,VolumeX,Pause,Play,Headphones,Heart,RotateCcw,Music2} from 'lucide-react';
import {SceneAudio,type SceneAudioControl} from '@/components/scene-audio';
import {Progress} from '@/components/ui/progress';
import {action,freshGame,step,playerX,jumpHeight,lanes, type Mode} from '@/lib/game';
const calls=[['LUCAS','Max，看着我！我们就在这里！'],['DUSTIN','跟着音乐跑，别停下来！'],['STEVE','出口就在前面，快过来！'],['LUCAS','你不是一个人。我们都在等你！'],['DUSTIN','Max，你能听见吗？快回来！']];
export default function Home(){
 const game=useRef(freshGame()),canvas=useRef<HTMLCanvasElement>(null),audio=useRef<SceneAudioControl|null>(null);
 const [mode,setMode]=useState<Mode>('ready'),[sound,setSound]=useState(false),[loaded,setLoaded]=useState(false),[loadError,setLoadError]=useState(false);
 const [hud,setHud]=useState({distance:0,hp:3,energy:0,notes:0,time:0,boost:0});
 const [call,setCall]=useState(0);const spoken=useRef(-1);
 function start(){if(!loaded)return;game.current=freshGame();game.current.mode='playing';setMode('playing');spoken.current=-1;audio.current?.play(true); }
 function pause(){const g=game.current;if(g.mode==='playing'){g.mode='paused';audio.current?.pause();}else if(g.mode==='paused'){g.mode='playing';audio.current?.play();}setMode(g.mode);}
 function control(key:string){const g=game.current;action(g,key);}
 function toggleSound(){audio.current?.toggle();}
 useEffect(()=>{
 const bg=new Image(),sprite=new Image();let dead=false,raf=0,last=0,lastHud=0;let assets=0;
 const ready=()=>{assets++;if(assets===2&&!dead)setLoaded(true);};const error=()=>{if(!dead)setLoadError(true);};
 bg.onload=ready;sprite.onload=ready;bg.onerror=error;sprite.onerror=error;bg.src='./world.jpg';sprite.src='./max-run-atlas.png';
 const c=canvas.current!,ctx=c.getContext('2d')!;
 function draw(t:number){if(dead)return;const dt=last?Math.min((t-last)/1000,.05):0;last=t;const g=game.current;const oldMode=g.mode;step(g,dt);
 if(g.mode!==oldMode){setMode(g.mode);audio.current?.pause();}
 if(g.mode==='playing'){
 const line=Math.floor(g.time/7);if(line!==spoken.current){spoken.current=line;setCall(line%calls.length);}
 }
 if(t-lastHud>90){setHud({distance:g.distance,hp:g.hp,energy:g.energy,notes:g.notes,time:g.time,boost:g.boost});lastHud=t;}
 ctx.clearRect(0,0,1200,680);ctx.fillStyle='#170908';ctx.fillRect(0,0,1200,680);
 if(bg.complete&&bg.naturalWidth)ctx.drawImage(bg,0,0,1200,680);
 const shade=ctx.createLinearGradient(0,0,0,680);shade.addColorStop(0,'#03050945');shade.addColorStop(.55,'#03050900');shade.addColorStop(1,'#05060bc9');ctx.fillStyle=shade;ctx.fillRect(0,0,1200,680);
 const anim=g.mode==='paused'?g.time:t/1000;
 for(let i=0;i<48;i++){const x=(i*167.3-anim*(11+i%7)+24000)%1200,y=(i*91+Math.sin(anim*.5+i)*22)%680;ctx.fillStyle=i%4===0?'#9effdf88':'#efaa9b55';ctx.beginPath();ctx.arc(x,y,i%3===0?1.8:.9,0,Math.PI*2);ctx.fill();}
 if(g.mode!=='ready'){
 for(let i=0;i<3;i++){ctx.strokeStyle=i===g.lane?'#a8ffeb44':'#ffffff10';ctx.lineWidth=1;ctx.setLineDash([7,13]);ctx.beginPath();ctx.moveTo(65,lanes[i]+5);ctx.lineTo(1050,lanes[i]+5);ctx.stroke();}ctx.setLineDash([]);
 for(const item of g.items){const x=item.x,y=lanes[item.lane];ctx.save();if(item.kind==='note'){ctx.shadowColor='#90ffdc';ctx.shadowBlur=20;ctx.fillStyle='#b4ffe9';ctx.font='bold 42px Georgia';ctx.fillText('♪',x-14,y-7);ctx.strokeStyle='#9affcc44';ctx.beginPath();ctx.arc(x,y-22,27,0,Math.PI*2);ctx.stroke();}else{ctx.shadowColor='#ff304b';ctx.shadowBlur=13;ctx.fillStyle='#300c20';ctx.strokeStyle='#ff6377';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x-25,y);ctx.lineTo(x-17,y-26);ctx.lineTo(x-3,y-18);ctx.lineTo(x+7,y-63);ctx.lineTo(x+23,y-14);ctx.lineTo(x+29,y);ctx.closePath();ctx.fill();ctx.stroke();}ctx.restore();}
 }
 if(sprite.complete&&sprite.naturalWidth){const x=g.mode==='ready'?350:playerX(g),y=g.mode==='ready'?554:g.y;const h=g.mode==='ready'?254:173;const w=h*360/370;const frame=g.jump>0?3:Math.floor((g.mode==='ready'?t/1000:g.runTime)*12)%8;const jumping=jumpHeight(g);ctx.save();ctx.fillStyle='#0008';ctx.beginPath();ctx.ellipse(x,y+7,40-jumping*.12,8,0,0,Math.PI*2);ctx.fill();ctx.translate(x,y-jumping);if(g.boost>0){ctx.shadowColor='#8dffe5';ctx.shadowBlur=30;}if(g.invincible>0&&Math.floor(t/80)%2===0)ctx.globalAlpha=.45;ctx.drawImage(sprite,frame*360,0,360,370,-w/2,-h*351/370,w,h);ctx.restore();}
 if(g.flash>0){ctx.fillStyle=`rgba(255,20,50,${g.flash*.7})`;ctx.fillRect(0,0,1200,680);}
 raf=requestAnimationFrame(draw);
 }raf=requestAnimationFrame(draw);
 const key=(e:KeyboardEvent)=>{if(e.target instanceof HTMLButtonElement&&[' ','Enter'].includes(e.key))return;const map:Record<string,string>={ArrowUp:'up',w:'up',W:'up',ArrowDown:'down',s:'down',S:'down',' ':'jump',e:'boost',E:'boost'};if(map[e.key]){e.preventDefault();if(!e.repeat)control(map[e.key]);}if(e.key==='Escape'||e.key==='p'||e.key==='P'){e.preventDefault();if(!e.repeat)pause();}};
 const visibility=()=>{if(document.hidden&&game.current.mode==='playing'){game.current.mode='paused';setMode('paused');audio.current?.pause();}};
 window.addEventListener('keydown',key);document.addEventListener('visibilitychange',visibility);
 return()=>{dead=true;cancelAnimationFrame(raf);window.removeEventListener('keydown',key);document.removeEventListener('visibilitychange',visibility);audio.current?.pause();};
 },[]);
 useEffect(()=>{
 const context=(document as Document & {modelContext?:{registerTool:(tool:Record<string,unknown>,options:{signal:AbortSignal})=>void|Promise<void>}}).modelContext;
 if(!context?.registerTool)return;
 const lifecycle=new AbortController();
 const snapshot=()=>{const g=game.current;return {mode:g.mode,distance:Math.floor(g.distance),lane:g.lane,health:g.hp,energy:g.energy,notes:g.notes,animation:{frame:g.jump>0?3:Math.floor(g.runTime*12)%8,elapsed:g.runTime},audio:audio.current?.getStatus()??null};};
 const tools=[{name:'read_escape_status',description:'Read the current Max escape game state.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute:snapshot},{name:'control_max_escape',description:'Start or restart a run, pause or resume it, change lane, jump, or trigger an available music boost, or toggle soundtrack playback. Updates the same game as the visible controls.',inputSchema:{type:'object',properties:{action:{type:'string',enum:['start','pause','resume','up','down','jump','boost','music']}},required:['action'],additionalProperties:false},annotations:{readOnlyHint:false},execute:async(input:unknown)=>{const a=(input as {action?:string})?.action;if(!a||!['start','pause','resume','up','down','jump','boost','music'].includes(a))throw new Error('Unknown game action');if(a==='music'){toggleSound();}else if(a==='start'){if(!loaded)throw new Error('Game art is still loading');start();}else if(a==='pause'||a==='resume'){if((a==='pause'&&game.current.mode==='playing')||(a==='resume'&&game.current.mode==='paused'))pause();}else{if(game.current.mode!=='playing')throw new Error('Start or resume the game first');control(a);}await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));return snapshot();}}];
 for(const tool of tools){try{void Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}}
 return()=>lifecycle.abort();
 },[loaded]);
 const inGame=mode==='playing'||mode==='paused';
 return <main className="shell">
 <header className="masthead"><a className="wordmark" href="./" aria-label="Max 跑回现实首页">STRANGER<span>THINGS</span></a><div className="edition"><span className="red-dot"/> 异世界逃脱 <span className="edition-rule"/> A FAN-MADE GAME</div><button className="icon-button" onClick={toggleSound} aria-pressed={sound} aria-label={sound?'暂停音乐':'播放音乐'} title={sound?'暂停音乐':'播放音乐'}>{sound?<Volume2 size={19}/>:<VolumeX size={19}/>}</button></header>
 <section className={`game-stage ${mode==='won'?'escaped':''}`} aria-label="Max 异世界逃脱游戏">
 <canvas ref={canvas} width={1200} height={680} aria-label="Max 向右奔跑。使用上下方向键换道，空格跳跃，E 冲刺。"/>
 <div className="stage-top"><span className="location"><span/> {mode==='won'?'HAWKINS, INDIANA':'THE UPSIDE DOWN'}</span><span className="chapter">CHAPTER 01 <span>／</span> THE WAY BACK</span></div>
 {mode==='ready'&&<div className="intro"><p className="eyebrow">MAX · ESCAPE THE UPSIDE DOWN</p><h1>跑回<span>现实</span></h1><p className="intro-copy">音乐还在响。朋友们还在等你。<br/>别回头，朝着他们的声音跑。</p><button className="start-button" onClick={start} disabled={!loaded}>{loadError?'画面加载失败，请刷新':loaded?'戴上耳机，开始逃脱':'正在连接另一个世界…'}<ArrowUpRight size={21}/></button><span className="start-note"><Headphones size={14}/> Kate Bush 原曲 · 每局约 45 秒</span></div>}
 {inGame&&<><div className="health" aria-label={`剩余生命 ${hud.hp} 次`}>{[0,1,2].map(i=><Heart key={i} size={23} fill={i<hud.hp?'currentColor':'transparent'} style={{opacity:i<hud.hp?1:.25}}/>)}</div><button className="pause-button icon-button" onClick={pause} aria-label={mode==='paused'?'继续游戏':'暂停游戏'}>{mode==='paused'?<Play size={20}/>:<Pause size={20}/>}</button><div className="callout" aria-live="polite"><span>{calls[call][0]} <i>游戏提示字幕</i></span><p>“{calls[call][1]}”</p></div><div className="run-label">{hud.boost>0?'音乐正在保护你':'奔向出口'}<span>{Math.max(0,1000-Math.floor(hud.distance))} m</span></div></>}
 {mode==='paused'&&<div className="end-overlay"><p className="eyebrow">STAY WITH US</p><h2>先喘口气。</h2><p>朋友的声音，会一直在这里。</p><button className="start-button" onClick={pause}>继续奔跑 <Play size={18}/></button></div>}
 {(mode==='won'||mode==='lost')&&<div className="end-overlay"><p className="eyebrow">{mode==='won'?'WELCOME HOME, MAX':'WE ARE STILL HERE'}</p><h2>{mode==='won'?'你回来了。':'别放弃，Max。'}</h2><p>{mode==='won'?'Lucas 接住了你。朋友们终于又在一起。':'朋友的声音还没有消失，再跟着音乐跑一次。'}</p><div className="result-stats"><span>{hud.time.toFixed(1)}<small>奔跑秒数</small></span><span>{hud.notes}<small>收集音符</small></span><span>{Math.floor(hud.distance)}<small>前进米数</small></span></div><button className="start-button" onClick={start}>再跑一次 <RotateCcw size={18}/></button></div>}
 <div className="scene-caption">{mode==='ready'?'“Max！我们就在这里！”':'KEEP THE MUSIC PLAYING'}</div>
 </section>
 <section className="dashboard" aria-label="游戏状态与操作">
 <div className="distance-block"><div className="metric-label"><span>现实的方向</span><span>{Math.floor(hud.distance/10)}<small>%</small></span></div><Progress value={hud.distance/10} aria-label="逃脱进度"/><div className="track-label"><span>异世界</span><span>朋友身边 ↗</span></div></div>
 <div className="energy-block"><div className="metric-label"><span><Music2 size={16}/> 音乐能量</span><span>{hud.energy}<small>/100</small></span></div><Progress className="energy-progress" value={hud.energy} aria-label="音乐能量"/><p>{hud.energy>=100?'能量已满，按 E 冲破障碍':'收集绿色音符，充满后获得 3 秒无敌冲刺'}</p></div>
 <div className="controls"><div><button aria-label="向上换道" disabled={mode!=='playing'} onClick={()=>control('up')}><ArrowUp size={17}/></button><button aria-label="向下换道" disabled={mode!=='playing'} onClick={()=>control('down')}><ArrowDown size={17}/></button><span>换道</span></div><div><button className="space-key" disabled={mode!=='playing'} onClick={()=>control('jump')}>SPACE</button><span>跳跃</span></div><div><button className={hud.energy>=100?'charged':''} disabled={mode!=='playing'||hud.energy<100} onClick={()=>control('boost')}>E</button><span>冲刺</span></div></div>
 </section><SceneAudio ref={audio} onPlaybackChange={setSound}/><footer><span>MAX / THE WAY BACK</span><p>避开红色碎石 · 收集绿色音符 · 三次受伤后重新开始</p><span>非官方同人小游戏 · Kate Bush 官方原曲</span></footer>
 </main>;
}
